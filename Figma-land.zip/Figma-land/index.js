
$(function()
{

    $('.seemore').click(function()
    {

        $('.center__imgcardparts').slideToggle(500)
    })
})